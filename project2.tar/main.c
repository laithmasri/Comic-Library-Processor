// As a Hokie, I will conduct myself with honor and integrity at all times.  
// I will not lie, cheat, or steal, nor will I accept the actions of those who do.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "comic.h"

int main (int argc, char* argv[])
{
    //Checking if the number or arguments is acceptable or not.
    if (argc != 3)
    {
        fprintf(stderr, "The number of arguments is incorrect.\n");
        exit(1);
    }

    FILE* input = fopen(argv[1], "r");
    FILE* output = fopen(argv[2], "w");

    char command[10];
    char variable[50];
    int position;
    
    fscanf(input, "%s", command);
    fscanf(input, "%s", variable);
    
    fprintf(output,"Command: %s %s\n", command, variable);
    struct ComicList theList;
    initializeList(&theList);

    struct ComicList buyList;
    initializeList(&buyList);

    load(variable, output, &theList);
    //float x = atof((theList).data[0].cost);
    //printf("%lf", x);
    //printf("%s\n", (theList).data[0].cost);
    //(theList).data[0].cost = (theList).data[0].cost + 1;
    //printf("%s\n", (theList).data[0].cost);
    //fprintf(output, "values in list after method: %d\n", (theList).count);
    //fprintf(output, "size of list: %d\n", (theList).size);
    
    while (!feof(input))
    {
        char command[10] = "\0";
        char variable[10] = "\0";
        position = 0;
        fscanf(input, "%s", command);
        if (strcmp(command, "load") == 0)
        {
            fscanf(input, "%s", variable);
            //printf("%s\n", command);
            fprintf(output,"Command: load %s\n", variable);
            //printf("%s\n", variable);
            load(variable, output, &theList);
        }
        else if (strcmp(command, "display") == 0)
        {
            fprintf(output, "Command: %s\n", command);
            display(theList, output);
        }
        else if (strcmp(command, "save") == 0)
        {
            
            fscanf(input, "%s", variable);
            //printf("this is the save variable:%s\n", variable);
            //fgetc(input);
            //printf("%s\n", variable);
            //fprintf(output, "i got in save\n");
            //FILE* out = fopen(variable, "w");
            fprintf(output, "Command: save %s\n", variable);
            save(theList, variable);
            //save();
        }
        else if (strcmp(command, "clear") == 0)
        {
            //fprintf(output, "i got in clear\n");
            fprintf(output, "Command: %s\n", command);
            clear(&theList);
            //printf("the first item in the list after clear is: %s\n", (theList).data[0].cost);
        }
        else if (strcmp(command, "buy") == 0)
        {
            fscanf(input, "%d", &position);
            fprintf(output, "Command: %s %d\n", command, position);
            
            //fprintf(output, "i got in buy\n");
            //printf("counter of buylist before method is %d\n", (buyList).count);
            buy(theList, &buyList, position, output);
            //printf("counter of buylist after method is %d\n", (buyList).count);
        }
        else if (strcmp(command, "checkout") == 0)
        {
            fprintf(output, "Command: %s\n", command);
            checkout(buyList, output);
        }
        else if (strcmp(command, "find") == 0)
        {
            fscanf(input, "%d", &position);
            fprintf(output, "Command: %s %d\n", command, position);
            find(theList, position, output);
        }
        else if (strcmp(command, "remove") == 0)
        {
            fscanf(input, "%d", &position);
            fprintf(output, "Command: %s %d\n", command, position);
            bool removed = remover(&theList, position);
            if (removed)
            {
                fprintf(output, "Comic at index %d successfully removed\n", position);
                //printf("removed position %d with cost %s\n", position, (theList).data[position].cost);
            }
            else
            {
                fprintf(output, "Comic at index %d was not removed\n", position);
            }
            //printf("counter of list before: %d\n", (theList).count);
            
            //printf("counter of list after: %d\n", (theList).count);
        }
    }
    //freeList(&theList);
    fclose(input);
    fclose(output);
}